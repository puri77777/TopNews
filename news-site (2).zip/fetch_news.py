#!/usr/bin/env python3
"""
NewsFeed Auto-Updater
Fetches Google News RSS feeds and builds a static news.json file.
Run this via GitHub Actions every 15-20 minutes.
"""

import json
import xml.etree.ElementTree as ET
import urllib.request
import urllib.parse
import time
import re
from datetime import datetime, timezone
from html import unescape

# Google News RSS feeds (FREE, no API key needed)
FEEDS = {
    "top": "https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en",
    "world": "https://news.google.com/rss/headlines/section/topic/WORLD?hl=en-US&gl=US&ceid=US:en",
    "business": "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-US&gl=US&ceid=US:en",
    "technology": "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-US&gl=US&ceid=US:en",
    "science": "https://news.google.com/rss/headlines/section/topic/SCIENCE?hl=en-US&gl=US&ceid=US:en",
    "health": "https://news.google.com/rss/headlines/section/topic/HEALTH?hl=en-US&gl=US&ceid=US:en",
    "sports": "https://news.google.com/rss/headlines/section/topic/SPORTS?hl=en-US&gl=US&ceid=US:en",
    "entertainment": "https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT?hl=en-US&gl=US&ceid=US:en",
}

# Additional direct source RSS feeds for redundancy
EXTRA_FEEDS = {
    "world": [
        "https://feeds.bbci.co.uk/news/world/rss.xml",
        "https://feeds.reuters.com/reuters/worldnews",
    ],
    "technology": [
        "https://feeds.arstechnica.com/arstechnica/index",
        "https://www.theverge.com/rss/index.xml",
    ],
    "business": [
        "https://feeds.bbci.co.uk/news/business/rss.xml",
    ],
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'application/rss+xml, application/xml, text/xml, */*',
}

def fetch_rss(url, retries=2):
    """Fetch and parse an RSS feed."""
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=15) as response:
                data = response.read()
                # Try to detect encoding
                try:
                    text = data.decode('utf-8')
                except:
                    text = data.decode('utf-8', errors='replace')
                return text
        except Exception as e:
            if attempt == retries:
                print(f"Failed to fetch {url}: {e}")
                return None
            time.sleep(2)
    return None

def parse_google_news_rss(xml_text, default_category="General"):
    """Parse Google News RSS XML into article dicts."""
    articles = []
    if not xml_text:
        return articles

    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as e:
        print(f"XML parse error: {e}")
        return articles

    # Find channel/items (handle RSS 2.0 and Atom)
    channel = root.find('.//channel')
    if channel is None:
        items = root.findall('.//{http://www.w3.org/2005/Atom}entry')
        if not items:
            items = root.findall('.//item')
    else:
        items = channel.findall('item')

    for item in items:
        try:
            title = item.findtext('title', '')
            link = item.findtext('link', '')
            desc = item.findtext('description', '')
            pub_date = item.findtext('pubDate', '')
            source_elem = item.find('source')
            source = source_elem.text if source_elem is not None else ''

            # Clean up title
            title = unescape(title).strip()
            # Google News format: "Title - Source"
            if ' - ' in title and not source:
                parts = title.rsplit(' - ', 1)
                title = parts[0].strip()
                source = parts[1].strip()

            # Clean description (remove HTML)
            desc = re.sub(r'<[^>]+>', '', desc)
            desc = unescape(desc).strip()

            # Parse date
            pub_dt = None
            if pub_date:
                try:
                    # RFC 2822 format
                    pub_dt = datetime.strptime(pub_date, '%a, %d %b %Y %H:%M:%S %Z')
                except:
                    try:
                        pub_dt = datetime.strptime(pub_date, '%a, %d %b %Y %H:%M:%S %z')
                    except:
                        pass

            if not pub_dt:
                pub_dt = datetime.now(timezone.utc)

            # Make timezone-aware
            if pub_dt.tzinfo is None:
                pub_dt = pub_dt.replace(tzinfo=timezone.utc)

            # Extract image from description if present
            image = None
            img_match = re.search(r'<img[^>]+src=["']([^"']+)["']', item.findtext('description', ''))
            if img_match:
                image = img_match.group(1)

            # Google News media content
            media = item.find('.//{http://search.yahoo.com/mrss/}thumbnail')
            if media is not None:
                image = media.get('url', image)

            # Skip if too old (older than 7 days)
            age = datetime.now(timezone.utc) - pub_dt
            if age.days > 7:
                continue

            # Deduplicate by link
            if any(a['link'] == link for a in articles):
                continue

            articles.append({
                'title': title,
                'link': link,
                'description': desc[:300] if desc else '',
                'pubDate': pub_dt.isoformat(),
                'source': source or 'Unknown',
                'category': default_category,
                'image': image,
            })
        except Exception as e:
            print(f"Error parsing item: {e}")
            continue

    return articles

def resolve_redirect(url):
    """Follow Google News redirect to get real URL."""
    try:
        req = urllib.request.Request(url, headers=HEADERS, method='HEAD')
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.geturl()
    except:
        return url

def main():
    all_articles = []

    print("Fetching Google News feeds...")
    for category, url in FEEDS.items():
        print(f"  → {category}...")
        xml = fetch_rss(url)
        if xml:
            articles = parse_google_news_rss(xml, category.capitalize())
            print(f"     Got {len(articles)} articles")
            all_articles.extend(articles)
        time.sleep(1)  # Be polite

    # Fetch extra feeds for redundancy
    print("Fetching backup feeds...")
    for category, urls in EXTRA_FEEDS.items():
        for url in urls:
            print(f"  → {category} (backup)...")
            xml = fetch_rss(url)
            if xml:
                articles = parse_google_news_rss(xml, category.capitalize())
                print(f"     Got {len(articles)} articles")
                all_articles.extend(articles)
            time.sleep(1)

    # Deduplicate by title similarity
    seen_titles = set()
    unique_articles = []
    for article in all_articles:
        # Simple dedup: normalize title
        norm = re.sub(r'[^a-zA-Z0-9]', '', article['title'].lower())
        if norm and norm not in seen_titles:
            seen_titles.add(norm)
            unique_articles.append(article)

    # Sort by date (newest first)
    unique_articles.sort(key=lambda x: x['pubDate'], reverse=True)

    # Keep only top 100
    unique_articles = unique_articles[:100]

    # Build output
    output = {
        'lastUpdate': datetime.now(timezone.utc).isoformat(),
        'totalArticles': len(unique_articles),
        'categories': list(set(a['category'] for a in unique_articles)),
        'articles': unique_articles,
    }

    with open('news.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"\n✅ Built news.json with {len(unique_articles)} articles")
    print(f"📅 Last update: {output['lastUpdate']}")
    print(f"📂 Categories: {', '.join(output['categories'])}")

if __name__ == '__main__':
    main()

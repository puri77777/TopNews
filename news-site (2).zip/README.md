# 📰 NewsFeed — Auto-Updating News Site

A Google News-style website that auto-updates every 15 minutes using free Google News RSS feeds. No API keys. No paid services. Hosted free on Cloudflare Pages.

---

## 🚀 Quick Setup (5 minutes)

### 1. Create a GitHub Repository
- Go to [github.com/new](https://github.com/new)
- Name it `newsfeed` (or anything)
- Make it **Public**
- Click **Create repository**

### 2. Upload These Files
Upload all files from this folder to your repo:
- `index.html` — The news website frontend
- `fetch_news.py` — The news scraper script
- `.github/workflows/update.yml` — Auto-update scheduler
- `news.json` — Will be auto-generated (can start empty: `{}`)

### 3. Connect to Cloudflare Pages
1. Go to [dash.cloudflare.com](https://dash.cloudflare.com) → **Pages**
2. Click **Create a project** → **Connect to Git**
3. Select your `newsfeed` repo
4. Framework preset: **None**
5. Build command: **(leave empty)**
6. Build output directory: **(leave empty / root)**
7. Click **Save and Deploy**

Your site will be live at `https://newsfeed-xxx.pages.dev`

### 4. Enable Auto-Updates
The GitHub Actions workflow runs every 15 minutes automatically. 

To verify it's working:
- Go to your repo → **Actions** tab
- You should see workflow runs every 15 minutes
- Each run updates `news.json` with fresh news

---

## 📁 File Structure

```
newsfeed/
├── .github/
│   └── workflows/
│       └── update.yml      # Auto-update every 15 min
├── index.html              # News website (Google News style)
├── fetch_news.py           # Fetches Google News RSS
├── news.json               # Auto-generated news data
└── README.md               # This file
```

---

## 🔄 How It Works

```
GitHub Actions (every 15 min)
    ↓
fetch_news.py runs
    ↓
Fetches 8 Google News RSS feeds (Top, World, Business, Tech, etc.)
    ↓
Parses + deduplicates + sorts articles
    ↓
Saves to news.json
    ↓
Git commit + push
    ↓
Cloudflare Pages auto-deploys (≈1 min)
    ↓
Website shows fresh news!
```

---

## 🆓 Completely Free Stack

| Component | Service | Cost |
|-----------|---------|------|
| Hosting | Cloudflare Pages | $0 |
| Auto-updates | GitHub Actions | $0 (public repos) |
| News data | Google News RSS | $0 (no API key) |
| Domain | `.pages.dev` | $0 |

---

## ⚙️ Customization

### Change Update Frequency
Edit `.github/workflows/update.yml`:
```yaml
# Every 15 minutes (default)
cron: '*/15 * * * *'

# Every 20 minutes
cron: '*/20 * * * *'

# Every hour
cron: '0 * * * *'
```

### Add More Categories
Edit `fetch_news.py` and add to `FEEDS` dict:
```python
"politics": "https://news.google.com/rss/search?q=politics&hl=en-US&gl=US&ceid=US:en",
"crypto": "https://news.google.com/rss/search?q=cryptocurrency&hl=en-US&gl=US&ceid=US:en",
```

### Change Region/Language
Replace `en-US` and `US` in feed URLs:
- UK: `hl=en-GB&gl=GB&ceid=GB:en`
- India: `hl=en-IN&gl=IN&ceid=IN:en`
- Philippines: `hl=en-PH&gl=PH&ceid=PH:en`

---

## ⚠️ Important Notes

- **Google News RSS** is free but unofficial. It may change without notice.
- **Rate limits**: The 15-minute interval is safe. Don't go below 10 minutes.
- **Images**: Not all articles have images. Placeholders are used as fallback.
- **Links**: Google News links redirect through `news.google.com` before reaching the publisher.
- **Copyright**: This is for personal/non-commercial use. Respect publishers' rights.

---

## 🛠️ Troubleshooting

**News not updating?**
- Check GitHub Actions tab for errors
- Make sure `news.json` is being committed
- Verify Cloudflare Pages is connected to the right branch

**Empty news.json?**
- Google News RSS may be temporarily blocked
- Try running `python fetch_news.py` locally to debug
- Check if your IP/range is rate-limited

**Site not loading?**
- Cloudflare Pages deploys take ~1 minute after push
- Check Cloudflare Pages dashboard for build errors

---

Made with ❤️ for free, forever-updating news.
